GUI REPLAY RECORDER - STAGE 1 (recording)
- Join any world (singleplayer or server). Recording starts automatically, stops when you leave.
- File: .minecraft/guirec/replays/replay_<time>.guirec  (small, MBs)
- F8 = status menu. Build via GitHub Actions (build.yml in this zip).
Next stages: in-game preview, then offline render to FFmpeg.
