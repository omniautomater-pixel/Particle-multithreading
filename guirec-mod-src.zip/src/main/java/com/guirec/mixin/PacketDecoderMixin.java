package com.guirec.mixin;

import com.guirec.ReplayRecorder;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.network.PacketDecoder;
import net.minecraft.network.ProtocolInfo;
import net.minecraft.network.protocol.PacketFlow;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/** Copies the raw bytes of every clientbound packet just before Minecraft decodes it. */
@Mixin(PacketDecoder.class)
public class PacketDecoderMixin {
    @Shadow @Final private ProtocolInfo<?> protocolInfo;

    @Inject(method = "decode", at = @At("HEAD"))
    private void guirec$capture(ChannelHandlerContext ctx, ByteBuf in, List<Object> out, CallbackInfo ci) {
        if (protocolInfo.flow() != PacketFlow.CLIENTBOUND) return;
        String phase = protocolInfo.id().name();
        if (!phase.equals("CONFIGURATION") && !phase.equals("PLAY")) return;
        byte[] raw = new byte[in.readableBytes()];
        in.getBytes(in.readerIndex(), raw);
        ReplayRecorder.onPacket(phase, raw);
    }
}
