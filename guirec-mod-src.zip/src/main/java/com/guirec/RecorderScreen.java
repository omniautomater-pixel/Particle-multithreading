package com.guirec;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Vanilla-style status menu (F8). Uses Minecraft's own widgets and font. */
public class RecorderScreen extends Screen {
    private final Screen parent;

    public RecorderScreen(Screen parent) {
        super(Component.literal("GUI Replay Recorder"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2 - 100, y = this.height / 4 + 24;
        addRenderableWidget(Button.builder(autoLabel(), b -> {
            ReplayRecorder.autoRecord = !ReplayRecorder.autoRecord;
            b.setMessage(autoLabel());
        }).bounds(cx, y, 200, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(cx, y + 30, 200, 20).build());
    }

    private Component autoLabel() {
        return Component.literal("Auto-record on world join: " + (ReplayRecorder.autoRecord ? "ON" : "OFF"));
    }

    private void line(GuiGraphicsExtractor g, String s, int y, int color) {
        var t = Component.literal(s).getVisualOrderText();
        g.text(this.font, t, this.width / 2 - this.font.width(t) / 2, y, color);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        super.extractRenderState(g, mouseX, mouseY, delta);
        line(g, this.title.getString(), this.height / 4 + 6, 0xFFFFFFFF);
        int y = this.height / 4 + 82;
        if (ReplayRecorder.isActive()) {
            line(g, "RECORDING  " + ReplayRecorder.packets + " packets, " + ReplayRecorder.states + " frames", y, 0xFFFF6666);
            line(g, String.format("File size: %.2f MB", ReplayRecorder.fileSize() / 1048576.0), y + 14, 0xFFAAAAAA);
        } else {
            line(g, ReplayRecorder.autoRecord ? "Waiting: recording starts when you join a world" : "Recording is OFF", y, 0xFFAAAAAA);
        }
        line(g, "Saved in .minecraft/guirec/replays/", y + 30, 0xFF777777);
    }

    @Override
    public void onClose() { this.minecraft.setScreen(parent); }

    @Override
    public boolean isPauseScreen() { return false; }
}
